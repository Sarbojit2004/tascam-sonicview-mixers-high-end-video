# TASCAM Sonicview — Part 1 · The Computational Core

Standalone Remotion project for `part1`. 1920x1080, 8940 frames at 30 fps.

## Rebuild

The derived media (`public/img`, `public/clips`, `public/audio`, `public/icon`,
`public/logo`) is ~160 MB and is NOT in this archive. It is all reproducible
from the source files in the repository root:

```bash
npm install
export SONICVIEW_MEDIA_DIR=/path/to/the/source/files
python3 scripts/prep_brand.py      # key the website icon, strip both logo plates
python3 scripts/prep_media.py      # 133 assets at two widths, 25 clips, 2 videos
python3 scripts/synth_audio.py     # 13 sound effects and 6 music beds, from code
```

`SONICVIEW_MEDIA_DIR` should point at the directory holding the 166 source
photographs and videos plus the 25 `SV-BR-*.mp4` clips.

## Verify, then render

```bash
node --experimental-strip-types scripts/audit_all.mts   # coverage, contact, compliance, glyphs
npx tsc --noEmit
npx remotion render part1/index.ts Part1 out/sonicview-part1.mp4 \
  --codec=h264 --crf=18 --pixel-format=yuv420p
node scripts/verify_render.mjs part1
```

## The standalone audio deliverables

```bash
node --experimental-strip-types scripts/emit_cues.mts
python3 scripts/export_audio.py    # music bed + SFX layer, each at exact runtime
```
